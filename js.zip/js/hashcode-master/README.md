Hashcode.js is a simple JavaScript module for generating hashcodes (integer representations) of objects.

For Docs, License, Tests and futher project related articles please see: https://github.com/stuartbannerman/hashcode
